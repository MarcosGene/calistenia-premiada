import { base44 } from './base44Client';


export const Challenge = base44.entities.Challenge;

export const VideoSubmission = base44.entities.VideoSubmission;



// auth sdk:
export const User = base44.auth;