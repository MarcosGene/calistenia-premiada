import React, { useState, useRef, useEffect } from "react";
import { VideoSubmission } from "@/api/entities";
import { Challenge } from "@/api/entities";
import { User } from "@/api/entities";
import { UploadFile } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, Camera, CheckCircle, AlertCircle, Target } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function UploadPage() {
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  const [currentChallenge, setCurrentChallenge] = useState(null);
  const [user, setUser] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [error, setError] = useState(null);
  const [aiCount, setAiCount] = useState('');
  const [videoSelected, setVideoSelected] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);

      const challenges = await Challenge.filter({ is_active: true }, '-created_date', 1);
      if (challenges.length > 0) {
        setCurrentChallenge(challenges[0]);
        
        // Verificar se já enviou vídeo esta semana
        const submissions = await VideoSubmission.filter({
          user_id: userData.id,
          challenge_id: challenges[0].id
        });
        
        if (submissions.length > 0) {
          setError("Você já enviou um vídeo para esta semana!");
        }
      } else {
        setError("Nenhum desafio ativo no momento.");
      }
    } catch (err) {
      setError("Erro ao carregar dados.");
    }
  };

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('video/')) {
      setError("Por favor, selecione apenas arquivos de vídeo.");
      return;
    }

    setSelectedFile(file);
    setVideoSelected(true);
    setError(null);
  };

  const handleConfirmUpload = async () => {
    if (!selectedFile || !aiCount) {
      setError("Por favor, confirme o número de repetições contadas pela IA.");
      return;
    }

    setUploading(true);
    setError(null);

    try {
      const { file_url } = await UploadFile({ file: selectedFile });
      
      // Criar submissão já aprovada automaticamente
      await VideoSubmission.create({
        user_id: user.id,
        challenge_id: currentChallenge.id,
        video_url: file_url,
        user_full_name: user.full_name,
        user_age: user.age,
        user_gender: user.gender,
        ai_count: parseInt(aiCount),
        manual_count: parseInt(aiCount), // Usar a contagem da IA como contagem manual
        status: 'approved' // Aprovado automaticamente
      });

      setUploadSuccess(true);
      setTimeout(() => {
        navigate(createPageUrl("Dashboard"));
      }, 2000);

    } catch (err) {
      setError("Erro ao fazer upload. Tente novamente.");
    }
    setUploading(false);
  };

  if (uploadSuccess) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 to-black flex items-center justify-center p-4">
        <Card className="bg-black/50 backdrop-blur-sm border-green-500/30 max-w-md w-full">
          <CardContent className="text-center p-8">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Vídeo Aprovado!</h2>
            <p className="text-gray-300">
              Seu vídeo foi automaticamente aprovado com <strong className="text-yellow-400">{aiCount} repetições</strong>. Confira sua posição no ranking!
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-black p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-black text-white mb-2">Enviar Vídeo</h1>
          <p className="text-gray-300">
            Grave seu vídeo fazendo {currentChallenge?.exercise_type} e envie para participar do desafio!
          </p>
        </div>

        {error && (
          <Card className="bg-red-500/20 border-red-500/30 mb-6">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-red-400" />
                <span className="text-red-300">{error}</span>
              </div>
            </CardContent>
          </Card>
        )}

        {currentChallenge && !error && (
          <Card className="bg-black/50 backdrop-blur-sm border-red-500/30">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Camera className="w-5 h-5 text-yellow-500" />
                Desafio da Semana: {currentChallenge.exercise_type.toUpperCase()}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-gradient-to-r from-red-600/20 to-yellow-500/20 p-6 rounded-lg">
                <h3 className="text-white font-bold mb-3">Instruções:</h3>
                <ul className="text-gray-300 space-y-2 list-disc list-inside">
                  <li>Máximo de repetições durante **30 segundos**.</li>
                  <li>Mantenha a **postura certa**. Nossa IA vai captar os movimentos corretos.</li>
                  <li>Filme de lado para melhor visualização.</li>
                  <li>Você pode enviar apenas **1 vídeo** por semana.</li>
                </ul>
              </div>

              {/* Step 1: Select Video */}
              {!videoSelected && (
                <div className="border-2 border-dashed border-gray-600 rounded-lg p-8 text-center">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="video/*"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                  
                  <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-white font-bold mb-2">Selecionar Vídeo</h3>
                  <p className="text-gray-300 mb-4">
                    Clique para escolher o arquivo do seu dispositivo
                  </p>
                  
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold"
                  >
                    Escolher Arquivo
                  </Button>
                </div>
              )}

              {/* Step 2: Confirm AI Count */}
              {videoSelected && !uploading && (
                <div className="bg-neutral-800 p-6 rounded-lg space-y-4">
                  <div className="flex items-center gap-3 mb-4">
                    <Target className="w-6 h-6 text-yellow-400" />
                    <h3 className="text-white font-bold text-lg">Confirme a Contagem da IA</h3>
                  </div>
                  
                  <p className="text-gray-300 mb-4">
                    Vídeo selecionado: <strong className="text-white">{selectedFile?.name}</strong>
                  </p>
                  
                  <div>
                    <Label className="text-white font-semibold">Quantas repetições a IA contou?</Label>
                    <Input
                      type="number"
                      placeholder="Ex: 25"
                      value={aiCount}
                      onChange={(e) => setAiCount(e.target.value)}
                      className="bg-gray-700 border-gray-600 text-white text-lg font-bold text-center"
                      min="0"
                      max="200"
                    />
                  </div>
                  
                  <div className="flex gap-3 pt-4">
                    <Button
                      onClick={() => {
                        setVideoSelected(false);
                        setSelectedFile(null);
                        setAiCount('');
                      }}
                      variant="outline"
                      className="flex-1"
                    >
                      Trocar Vídeo
                    </Button>
                    <Button
                      onClick={handleConfirmUpload}
                      disabled={!aiCount || parseInt(aiCount) < 1}
                      className="flex-1 bg-green-600 hover:bg-green-700 text-white font-bold"
                    >
                      ✅ Confirmar e Enviar
                    </Button>
                  </div>
                </div>
              )}

              {/* Loading State */}
              {uploading && (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-400 mx-auto mb-4"></div>
                  <p className="text-white font-semibold">Enviando vídeo...</p>
                </div>
              )}

              <div className="bg-yellow-500/20 p-4 rounded-lg">
                <p className="text-yellow-200 text-sm">
                  <strong>Prêmio desta semana:</strong> R$ {currentChallenge.prize_amount}
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}