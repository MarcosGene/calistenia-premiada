import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import CompleteProfile from "./CompleteProfile";

import Upload from "./Upload";

import Ranking from "./Ranking";

import Admin from "./Admin";

import Subscription from "./Subscription";

import AdminUsers from "./AdminUsers";

import Terms from "./Terms";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    CompleteProfile: CompleteProfile,
    
    Upload: Upload,
    
    Ranking: Ranking,
    
    Admin: Admin,
    
    Subscription: Subscription,
    
    AdminUsers: AdminUsers,
    
    Terms: Terms,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/CompleteProfile" element={<CompleteProfile />} />
                
                <Route path="/Upload" element={<Upload />} />
                
                <Route path="/Ranking" element={<Ranking />} />
                
                <Route path="/Admin" element={<Admin />} />
                
                <Route path="/Subscription" element={<Subscription />} />
                
                <Route path="/AdminUsers" element={<AdminUsers />} />
                
                <Route path="/Terms" element={<Terms />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}