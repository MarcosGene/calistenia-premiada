import React, { useState } from "react";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Crown, ArrowRight } from "lucide-react";
import { useNavigate, Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { getAgeCategory } from "../components/utils/ageCategories";

export default function CompleteProfile() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [formData, setFormData] = useState({
    phone: '',
    gender: '',
    age: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!agreedToTerms) {
      alert("Você deve concordar com os Termos de Uso para continuar.");
      return;
    }
    setLoading(true);

    try {
      await User.updateMyUserData({
        phone: formData.phone,
        gender: formData.gender,
        age: parseInt(formData.age),
        subscription_status: 'pending'
      });

      navigate(createPageUrl("Dashboard"));
    } catch (error) {
      console.error("Erro ao salvar dados:", error);
    }
    setLoading(false);
  };

  const ageCategory = formData.age ? getAgeCategory(parseInt(formData.age)) : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-black p-4">
      <div className="max-w-md mx-auto pt-10">
        <Card className="bg-neutral-800/50 backdrop-blur-sm border border-white/10">
          <CardHeader className="text-center">
            <Crown className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
            <CardTitle className="text-white text-2xl">Complete seu Perfil</CardTitle>
            <p className="text-neutral-300">
              Precisamos dessas informações para você participar dos desafios
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="phone" className="text-white">WhatsApp</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="(11) 99999-9999"
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  className="bg-gray-800 border-gray-600 text-white"
                  required
                />
              </div>

              <div>
                <Label htmlFor="gender" className="text-white">Gênero</Label>
                <Select value={formData.gender} onValueChange={(value) => setFormData({...formData, gender: value})} required>
                  <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                    <SelectValue placeholder="Selecione seu gênero" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="masculino">Masculino</SelectItem>
                    <SelectItem value="feminino">Feminino</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="age" className="text-white">Idade</Label>
                <Input
                  id="age"
                  type="number"
                  placeholder="25"
                  min="5"
                  max="70"
                  value={formData.age}
                  onChange={(e) => setFormData({...formData, age: e.target.value})}
                  className="bg-gray-800 border-gray-600 text-white"
                  required
                />
                {ageCategory && (
                  <p className="text-blue-400 text-sm mt-1">
                    Categoria: {ageCategory.label}
                  </p>
                )}
              </div>

              <div className="flex items-center space-x-2 pt-2">
                <Checkbox 
                  id="terms" 
                  checked={agreedToTerms}
                  onCheckedChange={setAgreedToTerms}
                  className="border-white"
                />
                <label
                  htmlFor="terms"
                  className="text-sm font-medium leading-none text-white peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  Li e concordo com os{' '}
                  <Link to={createPageUrl("Terms")} target="_blank" className="text-yellow-400 hover:underline">
                    Termos de Uso
                  </Link>
                </label>
              </div>

              <Button 
                type="submit" 
                className="w-full bg-yellow-400 hover:bg-yellow-300 text-black font-bold disabled:bg-neutral-500"
                disabled={loading || !agreedToTerms}
              >
                {loading ? (
                  "Salvando..."
                ) : (
                  <>
                    Continuar
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}