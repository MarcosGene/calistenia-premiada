
import React, { useState, useEffect } from "react";
import { VideoSubmission } from "@/api/entities";
import { Challenge } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Crown, Medal, Trophy, Calendar, Clock } from "lucide-react";
import { getAgeCategory, AGE_CATEGORIES } from "../components/utils/ageCategories";

export default function Ranking() {
  const [rankings, setRankings] = useState({});
  const [thisWeekChallenge, setThisWeekChallenge] = useState(null);
  const [lastWeekChallenge, setLastWeekChallenge] = useState(null);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedGender, setSelectedGender] = useState("masculino");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedPeriod, setSelectedPeriod] = useState("this_week"); // 'this_week' | 'last_week'

  useEffect(() => {
    loadInitialData();
  }, []);
  
  useEffect(() => {
    const challengeToLoad = selectedPeriod === "this_week" ? thisWeekChallenge : lastWeekChallenge;
    if (challengeToLoad) {
      loadRankingData(challengeToLoad.id);
    } else {
      setRankings({}); // Limpa o ranking se não houver desafio para o período
    }
  }, [selectedPeriod, thisWeekChallenge, lastWeekChallenge]);

  const loadInitialData = async () => {
    setLoading(true);
    try {
      const userData = await User.me();
      setUser(userData);

      // Busca os desafios, mais recentes primeiro
      const allChallenges = await Challenge.list('-week_start');
      
      // Encontra o desafio ativo (desta semana)
      const activeChallenge = allChallenges.find(challenge => challenge.is_active);
      
      // Encontra o desafio inativo mais recente (semana passada)
      const recentInactiveChallenge = allChallenges.find(challenge => !challenge.is_active);
      
      setThisWeekChallenge(activeChallenge);
      setLastWeekChallenge(recentInactiveChallenge);

    } catch (error) {
      console.error("Erro ao carregar dados iniciais:", error);
    }
    setLoading(false);
  };

  const loadRankingData = async (challengeId) => {
    try {
      const submissions = await VideoSubmission.filter({
        challenge_id: challengeId,
        status: 'approved'
      }, '-manual_count'); // Ainda ordena por contagem primeiro

      // Organiza por gênero e categoria de idade
      const organizedRankings = {
        masculino: {},
        feminino: {}
      };

      AGE_CATEGORIES.forEach(category => {
        organizedRankings.masculino[category.key] = [];
        organizedRankings.feminino[category.key] = [];
      });

      submissions.forEach((submission) => {
        if (submission.manual_count && submission.user_gender && submission.user_age) {
          const ageCategory = getAgeCategory(submission.user_age);
          const rankingEntry = {
            user: {
              id: submission.user_id,
              full_name: submission.user_full_name,
              age: submission.user_age,
              gender: submission.user_gender
            },
            count: submission.manual_count,
            ageCategory: ageCategory,
            videoUrl: submission.video_url,
            submissionDate: submission.created_date // Para critério de desempate
          };

          if (organizedRankings[submission.user_gender]?.[ageCategory.key]) {
            organizedRankings[submission.user_gender][ageCategory.key].push(rankingEntry);
          }
        }
      });

      // Ordenar cada categoria por contagem (decrescente) e depois por data de envio (crescente = primeiro envio ganha)
      Object.keys(organizedRankings).forEach(gender => {
        Object.keys(organizedRankings[gender]).forEach(category => {
          organizedRankings[gender][category].sort((a, b) => {
            // Primeiro critério: maior número de repetições
            if (b.count !== a.count) {
              return b.count - a.count;
            }
            // Segundo critério (empate): quem enviou primeiro
            return new Date(a.submissionDate) - new Date(b.submissionDate);
          });
        });
      });

      setRankings(organizedRankings);
    } catch (error) {
      console.error("Erro ao carregar ranking:", error);
    }
  };

  const getCurrentRanking = () => {
    if (!rankings[selectedGender]) return [];
    
    if (selectedCategory === "all") {
      const allEntries = [];
      Object.values(rankings[selectedGender]).forEach(categoryEntries => {
        allEntries.push(...categoryEntries);
      });
      // When combining "all" categories, we need to re-sort according to the same rules
      return allEntries.sort((a, b) => {
        if (b.count !== a.count) {
          return b.count - a.count;
        }
        return new Date(a.submissionDate) - new Date(b.submissionDate);
      });
    }
    
    return rankings[selectedGender][selectedCategory] || [];
  };

  const RankingList = ({ data }) => {
    if (loading && Object.keys(rankings).length === 0) {
      return (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-20 bg-neutral-800/50 rounded-lg animate-pulse"></div>
          ))}
        </div>
      );
    }
    
    if (data.length === 0) {
      return (
        <div className="text-center py-16 bg-neutral-800/50 rounded-2xl border border-white/10">
          <Medal className="w-16 h-16 text-neutral-500 mx-auto mb-4" />
          <p className="text-neutral-400">Nenhum participante nesta categoria ainda.</p>
        </div>
      );
    }

    return (
      <div className="space-y-3">
        {data.map((entry, index) => {
          const position = index + 1;
          const isTop10 = position <= 10;
          const isTop3 = position <= 3;
          let medalIcon = null;
          let cardClass = "bg-neutral-800/50 border-white/10";
          
          if (position === 1) {
            medalIcon = <Crown className="w-6 h-6 text-yellow-400" />;
            cardClass = "bg-yellow-400/10 border-yellow-400/50";
          } else if (position === 2) {
            medalIcon = <Medal className="w-6 h-6 text-gray-300" />;
            cardClass = "bg-gray-400/10 border-gray-400/50";
          } else if (position === 3) {
            medalIcon = <Medal className="w-6 h-6 text-orange-400" />;
            cardClass = "bg-orange-400/10 border-orange-400/50";
          }

          return (
            <Card key={`${entry.user.id}-${entry.ageCategory?.key}`} className={`border ${cardClass} transition-all duration-300`}>
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 text-2xl font-bold flex items-center justify-center text-neutral-400">
                    {isTop3 ? medalIcon : <span>{position}</span>}
                  </div>
                  <div className="w-12 h-12 rounded-full bg-neutral-700 flex items-center justify-center overflow-hidden">
                     <span className="text-black font-bold text-xl bg-gradient-to-br from-red-500 to-yellow-500 w-full h-full flex items-center justify-center">
                        {entry.user.full_name.charAt(0).toUpperCase()}
                     </span>
                  </div>
                  <div>
                    <h3 className="text-white font-bold">{entry.user.full_name}</h3>
                    <div className="flex items-center gap-2">
                      <p className="text-neutral-400 text-sm">{entry.user.age} anos</p>
                      {entry.ageCategory && selectedCategory === "all" && (
                        <span className="px-2 py-1 bg-blue-500/20 text-blue-300 text-xs rounded-full">
                          {entry.ageCategory.label}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  {user?.role === 'admin' ? (
                     <div className="flex flex-col items-end gap-2">
                      <div className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-red-500">
                        {entry.count}
                      </div>
                      <p className="text-neutral-500 text-sm -mt-1">repetições</p>
                      {isTop10 && entry.videoUrl && (
                        <a 
                          href={entry.videoUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-blue-400 hover:text-blue-300 underline text-xs font-medium"
                        >
                          🎥 Ver Vídeo
                        </a>
                      )}
                    </div>
                  ) : (
                    <div className="w-12 h-12 bg-neutral-700/50 rounded-lg flex items-center justify-center">
                      <Trophy className="w-6 h-6 text-yellow-400" />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    );
  };

  const currentData = getCurrentRanking();
  const activeChallenge = selectedPeriod === "this_week" ? thisWeekChallenge : lastWeekChallenge;

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-4xl font-black tracking-tighter text-white">Ranking dos Desafios</h1>
        {activeChallenge && (
          <p className="text-neutral-400 text-lg mt-1">
            Exercício: <strong className="text-red-400 capitalize">{activeChallenge.exercise_type}</strong> | Prêmio: <strong className="text-yellow-400">R$ {activeChallenge.prize_amount}</strong>
          </p>
        )}
      </div>

      <div className="mb-6">
        <Tabs value={selectedPeriod} onValueChange={setSelectedPeriod}>
          <TabsList className="grid w-full max-w-md grid-cols-2 bg-neutral-800 p-1 h-14 rounded-xl">
            <TabsTrigger 
              value="this_week" 
              className="text-base rounded-lg data-[state=active]:bg-gradient-to-r from-red-500 to-yellow-500 data-[state=active]:text-black data-[state=active]:font-bold data-[state=active]:shadow-lg flex items-center gap-2"
              disabled={!thisWeekChallenge}
            >
              <Clock className="w-5 h-5" />
              Esta Semana
            </TabsTrigger>
            <TabsTrigger 
              value="last_week" 
              className="text-base rounded-lg data-[state=active]:bg-gradient-to-r from-red-500 to-yellow-500 data-[state=active]:text-black data-[state=active]:font-bold data-[state=active]:shadow-lg flex items-center gap-2"
              disabled={!lastWeekChallenge}
            >
              <Calendar className="w-5 h-5" />
              Semana Passada
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Aviso sobre empates */}
      <div className="bg-blue-500/10 p-4 rounded-lg border border-blue-500/30 mb-6">
        <h3 className="text-blue-300 font-bold mb-2">ℹ️ Critério de Desempate</h3>
        <p className="text-blue-200 text-sm">
          Em caso de empate no número de repetições, <strong>quem enviou o vídeo primeiro</strong> fica na posição superior no ranking.
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <Tabs value={selectedGender} onValueChange={setSelectedGender}>
          <TabsList className="grid w-full grid-cols-2 bg-neutral-800 p-1 h-12 rounded-lg">
            <TabsTrigger value="masculino" className="text-base rounded-md data-[state=active]:bg-gradient-to-r from-red-500 to-yellow-500 data-[state=active]:text-black data-[state=active]:font-bold data-[state=active]:shadow-lg">
              👨 Masculino
            </TabsTrigger>
            <TabsTrigger value="feminino" className="text-base rounded-md data-[state=active]:bg-gradient-to-r from-red-500 to-yellow-500 data-[state=active]:text-black data-[state=active]:font-bold data-[state=active]:shadow-lg">
              👩 Feminino
            </TabsTrigger>
          </TabsList>
        </Tabs>

        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-full md:w-64 bg-neutral-800 border-neutral-700 text-white">
            <SelectValue placeholder="Selecionar categoria" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">🏆 Todas as Idades</SelectItem>
            {AGE_CATEGORIES.map((category) => (
              <SelectItem key={category.key} value={category.key}>
                {category.emoji} {category.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
        {AGE_CATEGORIES.map((category) => {
          const count = rankings[selectedGender]?.[category.key]?.length || 0;
          return (
            <Card 
              key={category.key} 
              className={`cursor-pointer transition-all duration-200 ${
                selectedCategory === category.key 
                  ? 'bg-yellow-400/20 border-yellow-400/50' 
                  : 'bg-neutral-800/50 border-neutral-700 hover:bg-neutral-800'
              }`}
              onClick={() => setSelectedCategory(category.key)}
            >
              <CardContent className="p-3 text-center">
                <div className="text-2xl mb-1">{category.emoji}</div>
                <div className="text-xs text-neutral-400 mb-1">{category.label.split('(')[0]}</div>
                <div className="font-bold text-white">{count}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {!activeChallenge && (
        <Card className="bg-neutral-800/50 border border-white/10 mb-6">
          <CardContent className="p-6 text-center">
            <Calendar className="w-12 h-12 text-neutral-500 mx-auto mb-4" />
            <p className="text-neutral-400">
              {selectedPeriod === "this_week" 
                ? "Nenhum desafio ativo esta semana." 
                : "Nenhum desafio encontrado para a semana passada."
              }
            </p>
          </CardContent>
        </Card>
      )}

      {activeChallenge && <RankingList data={currentData} />}
    </div>
  );
}
