import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, XCircle, ShieldCheck, AlertTriangle, Zap } from 'lucide-react';
import { addMonths, format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function SubscriptionPage() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    setLoading(true);
    try {
      const userData = await User.me();
      setUser(userData);
    } catch (error) {
      console.error("Erro ao carregar dados do usuário:", error);
    }
    setLoading(false);
  };

  const handleSubscribe = async () => {
    setActionLoading(true);
    try {
      await User.updateMyUserData({
        subscription_status: 'active',
        subscription_start_date: new Date().toISOString().split('T')[0]
      });
      await loadUserData(); // Recarrega os dados para atualizar a UI
    } catch (error) {
      console.error("Erro ao ativar assinatura:", error);
    }
    setActionLoading(false);
  };

  const handleCancel = async () => {
    if (window.confirm("Você tem certeza que deseja cancelar sua assinatura? Você perderá o acesso aos desafios.")) {
      setActionLoading(true);
      try {
        await User.updateMyUserData({
          subscription_status: 'inactive',
        });
        await loadUserData(); // Recarrega os dados para atualizar a UI
      } catch (error) {
        console.error("Erro ao cancelar assinatura:", error);
      }
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-yellow-400"></div>
      </div>
    );
  }

  const isActive = user?.subscription_status === 'active';
  const nextBillingDate = user?.subscription_start_date 
    ? format(addMonths(new Date(user.subscription_start_date), 1), 'dd/MM/yyyy', { locale: ptBR })
    : null;

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-4xl font-black tracking-tighter text-white">Gerenciar Assinatura</h1>
        <p className="text-neutral-400 text-lg mt-1">
          Controle seu plano e acesso aos desafios semanais.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <Card className="bg-neutral-800/50 border border-white/10">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <ShieldCheck className={`w-6 h-6 ${isActive ? 'text-green-400' : 'text-red-400'}`} />
              <span className="text-white">Seu Status</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between p-4 bg-neutral-900 rounded-lg">
              <span className="text-neutral-300">Status atual:</span>
              <Badge className={`font-bold text-base ${isActive ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'}`}>
                {isActive ? 'Ativa' : 'Inativa'}
              </Badge>
            </div>
            
            {isActive ? (
              <>
                <div className="space-y-2">
                  <p className="text-neutral-400">Assinatura iniciada em:</p>
                  <p className="font-semibold text-white">
                    {format(new Date(user.subscription_start_date), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                  </p>
                </div>
                <div className="space-y-2">
                  <p className="text-neutral-400">Próxima cobrança:</p>
                  <p className="font-semibold text-white">{nextBillingDate}</p>
                </div>
                <Button 
                  variant="destructive" 
                  className="w-full"
                  onClick={handleCancel}
                  disabled={actionLoading}
                >
                  <XCircle className="w-5 h-5 mr-2" />
                  {actionLoading ? "Cancelando..." : "Cancelar Assinatura"}
                </Button>
              </>
            ) : (
              <>
                <div className="text-center">
                  <p className="text-neutral-300 mb-4">
                    Sua assinatura está inativa. Ative-a para participar dos desafios e concorrer a prêmios!
                  </p>
                  <Button
                    size="lg"
                    className="w-full bg-yellow-400 hover:bg-yellow-300 text-black font-bold"
                    onClick={handleSubscribe}
                    disabled={actionLoading}
                  >
                    <Zap className="w-5 h-5 mr-2" />
                    {actionLoading ? "Ativando..." : "Ativar Assinatura - R$10/mês"}
                  </Button>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        <Card className="bg-blue-500/10 border border-blue-500/20">
          <CardHeader>
             <CardTitle className="flex items-center gap-3 text-blue-300">
               <AlertTriangle className="w-6 h-6" />
               Aviso Importante
             </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-blue-200">
              Este é um ambiente de demonstração. O botão "Ativar Assinatura" simula um pagamento bem-sucedido para fins de teste.
              <br/><br/>
              Para uma implementação em produção, é necessário integrar um serviço de pagamento real como Stripe, PagSeguro ou Mercado Pago, o que requer configuração de backend.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}