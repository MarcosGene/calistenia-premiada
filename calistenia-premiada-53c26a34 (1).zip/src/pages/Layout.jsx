

import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import { 
  Trophy, 
  Users, 
  Upload, 
  Home,
  Settings,
  LogOut,
  Menu,
  X,
  Crown,
  Zap,
  BarChart,
  CreditCard 
} from "lucide-react";
import { Button } from "@/components/ui/button";

// Componente para o Landing Page
const LandingPage = () => (
  <div className="min-h-screen w-full bg-neutral-900 text-white relative overflow-hidden flex flex-col">
    <div className="absolute inset-0 bg-grid-red-500/10 bg-[size:100px_100px] [mask-image:radial-gradient(ellipse_100%_40%_at_50%_60%,black,transparent)]"></div>
    
    <div className="container mx-auto px-4 sm:px-6 py-4 sm:py-8 relative z-10 flex-grow">
      <header className="flex justify-between items-center py-4 sm:py-6">
         <div className="flex items-center gap-2 sm:gap-3">
            <div className="w-8 h-8 sm:w-10 sm:h-10 bg-yellow-400 rounded-lg flex items-center justify-center">
              <Crown className="w-5 h-5 sm:w-6 sm:h-6 text-black" />
            </div>
            <h1 className="text-lg sm:text-2xl font-black tracking-tighter text-white">
              CALISTENIA <span className="text-yellow-400">PREMIADA</span>
            </h1>
          </div>
          <Button onClick={() => User.login()} variant="ghost" className="text-white hover:bg-white/10 text-sm sm:text-base">
            Login
          </Button>
      </header>

      <main className="text-center pt-16 sm:pt-24 pb-20 sm:pb-32">
        <h2 className="text-4xl sm:text-5xl md:text-7xl font-extrabold tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-red-500 mb-6">
          Desafie Seus Limites. Conquiste Prêmios.
        </h2>
        <p className="text-lg sm:text-xl md:text-2xl text-neutral-300 mb-10 max-w-3xl mx-auto">
          Participe de desafios semanais de calistenia, suba no ranking e ganhe prêmios em dinheiro. Apenas R$10/mês.
        </p>
        <Button 
          onClick={() => User.login()}
          size="lg"
          className="bg-yellow-400 hover:bg-yellow-300 text-black font-bold text-base sm:text-lg px-8 sm:px-10 py-5 sm:py-6 rounded-full shadow-lg shadow-yellow-400/20 transform hover:scale-105 transition-transform duration-300"
        >
          <Zap className="w-5 h-5 sm:w-6 h-6 mr-3" />
          COMEÇAR A COMPETIR
        </Button>
      </main>
    </div>
    
    <footer className="w-full bg-neutral-900 border-t border-white/10 py-4 relative z-10">
      <div className="container mx-auto px-4 sm:px-6 text-center text-neutral-400 text-sm">
        <p>&copy; {new Date().getFullYear()} Calistenia Premiada. Todos os direitos reservados.</p>
        <Link to={createPageUrl("Terms")} className="hover:text-yellow-400 underline">
          Termos de Uso e Serviço
        </Link>
      </div>
    </footer>
  </div>
);


export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    checkUser();
  }, [location.pathname]); // Re-check user on path change

  const checkUser = async () => {
    setLoading(true);
    try {
      const userData = await User.me();
      if (userData.account_status === 'banned') {
        alert("Sua conta foi banida por violar as regras do aplicativo.");
        await User.logout();
        setUser(null);
        window.location.reload();
      } else {
        setUser(userData);
      }
    } catch (error) {
      setUser(null);
    }
    setLoading(false);
  };

  const handleLogout = async () => {
    await User.logout();
    setUser(null);
    window.location.reload();
  };

  const userNavItems = [
    { name: "Dashboard", path: createPageUrl("Dashboard"), icon: Home },
    { name: "Ranking", path: createPageUrl("Ranking"), icon: BarChart },
    { name: "Enviar Vídeo", path: createPageUrl("Upload"), icon: Upload },
    { name: "Assinatura", path: createPageUrl("Subscription"), icon: CreditCard }, 
  ];

  const adminNavItems = [
    { name: "Admin", path: createPageUrl("Admin"), icon: Settings },
    { name: "Usuários", path: createPageUrl("AdminUsers"), icon: Users },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-neutral-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-yellow-400"></div>
      </div>
    );
  }

  if (!user && currentPageName !== "Terms" && !location.pathname.includes("auth")) {
    return <LandingPage />;
  }
  
  const needsUserData = user && (!user.phone || !user.gender || !user.age);
  
  if (needsUserData && currentPageName !== "CompleteProfile" && currentPageName !== "Terms") {
     return (
        <>
          <style>{`
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
            body { font-family: 'Inter', sans-serif; }
          `}</style>
          <div className="min-h-screen bg-neutral-900 text-white flex items-center justify-center p-4">
             <div className="max-w-md mx-auto text-center">
                <div className="p-8 bg-neutral-800/50 rounded-2xl border border-white/10">
                    <Crown className="w-16 h-16 text-yellow-400 mx-auto mb-6" />
                    <h2 className="text-2xl font-bold text-white mb-2">Complete seu Perfil</h2>
                    <p className="text-neutral-300 mb-6">
                      Para participar dos desafios e concorrer a prêmios, precisamos de mais algumas informações.
                    </p>
                    <Link to={createPageUrl("CompleteProfile")}>
                      <Button size="lg" className="w-full bg-yellow-400 hover:bg-yellow-300 text-black font-bold">
                        Completar Perfil Agora
                      </Button>
                    </Link>
                </div>
              </div>
          </div>
        </>
    );
  }

  const NavLink = ({ item, onClick }) => (
    <Link
      to={item.path}
      onClick={onClick}
      className={`group flex items-center gap-3 px-3 sm:px-4 py-2.5 sm:py-3 rounded-lg transition-all duration-200 ${
        location.pathname === item.path
          ? 'bg-gradient-to-r from-red-500/20 to-yellow-400/20 text-white font-semibold'
          : 'text-neutral-400 hover:text-white hover:bg-white/5'
      }`}
    >
      <item.icon className={`w-5 h-5 transition-colors duration-200 ${location.pathname === item.path ? 'text-yellow-400' : 'text-neutral-500 group-hover:text-white'}`} />
      <span className="text-sm sm:text-base">{item.name}</span>
    </Link>
  );

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
        body { font-family: 'Inter', sans-serif; }
      `}</style>
      <div className="min-h-screen bg-neutral-900 text-white">
        {/* Mobile Header */}
        <header className="md:hidden sticky top-0 bg-neutral-900/95 backdrop-blur-lg border-b border-white/10 px-4 py-3 z-50">
          <div className="flex items-center justify-between">
            <Link to={createPageUrl("Dashboard")} className="flex items-center gap-2">
              <div className="w-8 h-8 bg-yellow-400 rounded-lg flex items-center justify-center flex-shrink-0">
                <Crown className="w-5 h-5 text-black" />
              </div>
              <div className="flex flex-col leading-tight">
                <span className="font-black text-white text-sm tracking-tighter">CALISTENIA</span>
                <span className="font-black text-yellow-400 text-sm tracking-tighter -mt-1">PREMIADA</span>
              </div>
            </Link>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-white hover:bg-white/10 flex-shrink-0"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </Button>
          </div>
          
          {mobileMenuOpen && (
            <div 
              className="fixed inset-x-0 top-full bg-neutral-900/95 backdrop-blur-lg border-b border-white/10 p-4 shadow-xl"
              onClick={() => setMobileMenuOpen(false)}
            >
              <div className="space-y-2 max-w-sm mx-auto">
                {userNavItems.map((item) => <NavLink key={item.name} item={item} onClick={() => setMobileMenuOpen(false)} />)}
                {user?.role === 'admin' && (
                   <div className="pt-2 mt-2 border-t border-white/10">
                    {adminNavItems.map((item) => <NavLink key={item.name} item={item} onClick={() => setMobileMenuOpen(false)} />)}
                  </div>
                )}
                <button
                  onClick={handleLogout}
                  className="group flex items-center gap-3 px-3 py-2.5 rounded-lg text-red-400 hover:bg-red-500/10 w-full text-left"
                >
                  <LogOut className="w-5 h-5" />
                  <span className="text-sm">Sair</span>
                </button>
              </div>
            </div>
          )}
        </header>

        <div className="flex">
          {/* Desktop Sidebar */}
          <aside className="hidden md:flex flex-col w-64 border-r border-white/10 min-h-screen p-4 sticky top-0">
            <div className="p-4 mb-4">
              <Link to={createPageUrl("Dashboard")} className="flex items-center gap-3">
                <div className="w-10 h-10 bg-yellow-400 rounded-lg flex items-center justify-center">
                  <Crown className="w-6 h-6 text-black" />
                </div>
                <div>
                  <h2 className="font-black tracking-tighter text-white text-sm">CALISTENIA</h2>
                  <h2 className="font-black tracking-tighter text-yellow-400 text-sm -mt-1">PREMIADA</h2>
                </div>
              </Link>
            </div>

            <nav className="flex-1 space-y-2">
              {userNavItems.map((item) => <NavLink key={item.name} item={item} />)}
              
              {user?.role === 'admin' && (
                <>
                  <div className="pt-4 mt-4 border-t border-white/10">
                    <p className="px-4 text-xs font-semibold text-neutral-500 uppercase mb-2">Admin</p>
                    {adminNavItems.map((item) => <NavLink key={item.name} item={item} />)}
                  </div>
                </>
              )}
            </nav>

            <div className="p-2 border-t border-white/10">
              <div className="flex items-center gap-3 p-2 rounded-lg">
                 <div className="w-9 h-9 bg-gradient-to-br from-red-500 to-yellow-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-black font-bold">
                    {user?.full_name?.charAt(0)?.toUpperCase()}
                  </span>
                </div>
                <div className="flex-1 overflow-hidden">
                  <p className="text-white font-semibold text-sm truncate">{user?.full_name}</p>
                  <p className="text-neutral-400 text-xs truncate">{user?.email}</p>
                </div>
                <Button variant="ghost" size="icon" onClick={handleLogout} className="text-neutral-500 hover:text-red-400 flex-shrink-0">
                  <LogOut className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </aside>

          <main className="flex-1">
            <div className="p-4 sm:p-6 lg:p-8">
              {children}
            </div>
          </main>
        </div>
      </div>
    </>
  );
}

