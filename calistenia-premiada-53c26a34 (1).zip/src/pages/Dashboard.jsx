
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Challenge } from "@/api/entities";
import { VideoSubmission } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Trophy, 
  Upload, 
  Calendar, 
  DollarSign,
  Target,
  Crown,
  CheckCircle,
  Clock
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format, formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { getAgeCategory } from "../components/utils/ageCategories";

// Stat Card Component
const StatCard = ({ icon: Icon, title, value, colorClass, userCanParticipate }) => (
  <div className={`relative p-4 sm:p-6 rounded-2xl overflow-hidden transition-all duration-300 ${!userCanParticipate ? 'bg-neutral-800' : 'bg-neutral-800/50 hover:bg-neutral-800'}`}>
     <div className={`absolute -top-4 -right-4 w-16 h-16 sm:w-24 sm:h-24 rounded-full opacity-10 ${colorClass}`}></div>
     <Icon className={`absolute top-4 right-4 sm:top-6 sm:right-6 w-6 h-6 sm:w-8 sm:h-8 opacity-20 ${colorClass}`} />
     <p className="text-neutral-400 text-xs sm:text-sm font-medium mb-1">{title}</p>
     <p className={`text-xl sm:text-3xl font-bold ${colorClass}`}>{value}</p>
  </div>
);

// Countdown Timer Component
const CountdownTimer = ({ endDate }) => {
  const [timeLeft, setTimeLeft] = useState("");

  useEffect(() => {
    if (!endDate) return;

    const interval = setInterval(() => {
      const distance = new Date(endDate).getTime() - new Date().getTime();
      if (distance < 0) {
        setTimeLeft("Encerrado");
        clearInterval(interval);
        return;
      }
      
      const days = Math.floor(distance / (1000 * 60 * 60 * 24));
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      
      setTimeLeft(`${days}d ${hours}h ${minutes}m`);
    }, 1000);

    return () => clearInterval(interval);
  }, [endDate]);

  return (
    <div className="flex items-center gap-2">
      <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-red-400" />
      <span className="text-white font-semibold text-sm sm:text-base">{timeLeft}</span>
    </div>
  );
};


export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [currentChallenge, setCurrentChallenge] = useState(null);
  const [userSubmission, setUserSubmission] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);

      const challenges = await Challenge.filter({ is_active: true }, '-created_date', 1);
      if (challenges.length > 0) {
        setCurrentChallenge(challenges[0]);

        if (userData?.id) {
          const submissions = await VideoSubmission.filter({
            user_id: userData.id,
            challenge_id: challenges[0].id
          }, '-created_date', 1);

          if (submissions.length > 0) {
            setUserSubmission(submissions[0]);
          }
        }
      }
    } catch (error) {
      console.error("Erro ao carregar dashboard:", error);
    }
    setLoading(false);
  };


  if (loading || !user) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-yellow-400"></div>
      </div>
    );
  }

  const needsUserData = !user.phone || !user.gender || !user.age;
  
  if (needsUserData) {
    return (
      <div className="max-w-md mx-auto pt-6 sm:pt-10 text-center px-4">
        <div className="p-6 sm:p-8 bg-neutral-800/50 rounded-2xl border border-white/10">
            <Crown className="w-12 h-12 sm:w-16 sm:h-16 text-yellow-400 mx-auto mb-4 sm:mb-6" />
            <h2 className="text-xl sm:text-2xl font-bold text-white mb-2">Complete seu Perfil</h2>
            <p className="text-neutral-300 mb-4 sm:mb-6 text-sm sm:text-base">
              Para participar dos desafios e concorrer a prêmios, precisamos de mais algumas informações.
            </p>
            <Link to={createPageUrl("CompleteProfile")}>
              <Button size="lg" className="w-full bg-yellow-400 hover:bg-yellow-300 text-black font-bold">
                Completar Perfil Agora
              </Button>
            </Link>
        </div>
      </div>
    );
  }

  const userAgeCategory = user.age ? getAgeCategory(user.age) : null;
  const userCanParticipate = currentChallenge && !userSubmission && user.subscription_status === 'active';
  
  const subscriptionIsInactive = user.subscription_status === 'inactive' || user.subscription_status === 'pending';

  return (
    <div className="p-0">
      <div className="max-w-6xl mx-auto">
        <div className="mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tighter text-white">
            Bem-vindo, <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-red-500">{user.full_name?.split(' ')[0]}!</span>
          </h1>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 mt-1">
            <p className="text-neutral-400 text-base sm:text-lg">
              {userCanParticipate ? "Pronto para dominar o desafio desta semana?" : "Confira seu status e o desafio atual."}
            </p>
            {userAgeCategory && (
              <span className="px-3 py-1 bg-blue-500/20 text-blue-300 text-xs sm:text-sm rounded-full font-medium">
                Categoria: {userAgeCategory.label}
              </span>
            )}
          </div>
        </div>
        
        {subscriptionIsInactive && (
            <Card className="mb-6 sm:mb-8 bg-yellow-400/10 border-yellow-500/30">
                <CardContent className="p-4 sm:p-6 flex flex-col md:flex-row items-center justify-between gap-4">
                    <div>
                        <h3 className="text-lg sm:text-xl font-bold text-yellow-300">Ative sua Assinatura!</h3>
                        <p className="text-neutral-300 text-sm sm:text-base">Sua assinatura não está ativa. Ative agora para poder participar dos desafios semanais.</p>
                    </div>
                    <Link to={createPageUrl("Subscription")}>
                        <Button size="lg" className="w-full md:w-auto bg-yellow-400 hover:bg-yellow-300 text-black font-bold">
                            Ativar Assinatura
                        </Button>
                    </Link>
                </CardContent>
            </Card>
        )}

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6 mb-6 sm:mb-8">
          <StatCard icon={CheckCircle} title="Assinatura" value={user.subscription_status === 'active' ? 'Ativa' : 'Inativa'} colorClass={user.subscription_status === 'active' ? 'text-green-400' : 'text-red-400'} userCanParticipate={userCanParticipate} />
          <StatCard icon={DollarSign} title="Prêmios Ganhos" value={`R$ ${user.total_prizes_won || 0}`} colorClass="text-yellow-400" userCanParticipate={userCanParticipate} />
          <StatCard icon={Target} title="Exercício" value={currentChallenge?.exercise_type?.charAt(0).toUpperCase() + currentChallenge?.exercise_type?.slice(1) || 'N/A'} colorClass="text-red-400" userCanParticipate={userCanParticipate} />
          <StatCard icon={Trophy} title="Prêmio Semanal" value={`R$ ${currentChallenge?.prize_amount || 100}`} colorClass="text-yellow-400" userCanParticipate={userCanParticipate} />
        </div>

        {currentChallenge ? (
          <div className={`p-6 sm:p-8 rounded-2xl border border-white/10 ${userCanParticipate ? 'bg-gradient-to-br from-red-500/10 to-neutral-900' : 'bg-neutral-800/50'}`}>
            <div className="flex flex-col lg:flex-row justify-between items-start gap-4 sm:gap-6">
              <div className="flex-1">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 gap-2">
                    <h2 className="text-xl sm:text-2xl font-bold text-white">Desafio da Semana</h2>
                    {currentChallenge.week_end && <CountdownTimer endDate={currentChallenge.week_end} />}
                </div>
                <p className="text-neutral-300 text-base sm:text-lg">
                  O exercício é <strong className="text-red-400 capitalize">{currentChallenge.exercise_type}</strong>. Mostre seu melhor desempenho!
                </p>
                {userAgeCategory && (
                  <p className="text-neutral-400 mt-2 text-sm sm:text-base">
                    Você competirá na categoria <strong className="text-blue-400">{userAgeCategory.label}</strong>
                  </p>
                )}
              </div>
              
              {userCanParticipate && (
                <Link to={createPageUrl("Upload")}>
                  <Button size="lg" className="w-full lg:w-auto bg-yellow-400 hover:bg-yellow-300 text-black font-bold shadow-lg shadow-yellow-400/20 transform hover:scale-105 transition-transform duration-300">
                    <Upload className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                    Enviar Meu Vídeo
                  </Button>
                </Link>
              )}
            </div>
            
            {userSubmission && (
              <div className="mt-6 pt-6 border-t border-white/10">
                <h3 className="text-lg sm:text-xl font-bold text-white mb-4">Sua Submissão</h3>
                <div className="flex flex-wrap items-center gap-4 sm:gap-6 p-4 bg-neutral-800 rounded-lg">
                  <div>
                     <p className="text-neutral-400 text-xs sm:text-sm">Status</p>
                     <Badge 
                        className={`font-bold text-sm sm:text-base ${
                          userSubmission.status === 'approved' ? 'bg-green-500/20 text-green-300 border-green-500/30' :
                          userSubmission.status === 'rejected' ? 'bg-red-500/20 text-red-300 border-red-500/30' :
                          'bg-yellow-500/20 text-yellow-300 border-yellow-500/30'
                        }`}
                      >
                        {userSubmission.status === 'pending' ? 'Em Análise' : userSubmission.status.charAt(0).toUpperCase() + userSubmission.status.slice(1)}
                      </Badge>
                  </div>
                  <div>
                     <p className="text-neutral-400 text-xs sm:text-sm">Repetições (IA)</p>
                     <p className="font-bold text-xl sm:text-2xl text-white">{userSubmission.ai_count || 'N/A'}</p>
                  </div>
                  {userSubmission.manual_count && (
                    <div>
                      <p className="text-neutral-400 text-xs sm:text-sm">Repetições Válidas</p>
                      <p className="font-bold text-xl sm:text-2xl text-yellow-400">{userSubmission.manual_count}</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        ) : (
           <div className="text-center py-12 sm:py-16 bg-neutral-800/50 rounded-2xl border border-white/10">
              <Clock className="w-12 h-12 sm:w-16 sm:h-16 text-neutral-500 mx-auto mb-4" />
              <h2 className="text-xl sm:text-2xl font-bold text-white">Nenhum desafio ativo</h2>
              <p className="text-neutral-400">Volte em breve para o próximo desafio.</p>
            </div>
        )}
      </div>
    </div>
  );
}
