
import React, { useState, useEffect, useCallback } from "react";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Users as UsersIcon, Search, Filter, X, ShieldOff, ShieldCheck } from "lucide-react";
import { getAgeCategory } from "../components/utils/ageCategories";

export default function AdminUsers() {
  const [allUsers, setAllUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [genderFilter, setGenderFilter] = useState("all");
  const [ageFilter, setAgeFilter] = useState("all");
  const [accountStatusFilter, setAccountStatusFilter] = useState("all");

  useEffect(() => {
    loadUsers();
  }, []);

  const filterUsers = useCallback(() => {
    let filtered = allUsers;

    // Filtro por termo de busca
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(user =>
        user.full_name?.toLowerCase().includes(term) ||
        user.email?.toLowerCase().includes(term) ||
        user.phone?.includes(term)
      );
    }

    // Filtro por status de assinatura
    if (statusFilter !== "all") {
      filtered = filtered.filter(user => user.subscription_status === statusFilter);
    }

    // Filtro por status da conta
    if (accountStatusFilter !== "all") {
      filtered = filtered.filter(user => (user.account_status || 'active') === accountStatusFilter);
    }

    // Filtro por gênero
    if (genderFilter !== "all") {
      filtered = filtered.filter(user => user.gender === genderFilter);
    }

    // Filtro por faixa etária
    if (ageFilter !== "all") {
      filtered = filtered.filter(user => {
        if (!user.age) return false;
        const ageCategory = getAgeCategory(user.age);
        return ageCategory.key === ageFilter;
      });
    }

    setFilteredUsers(filtered);
  }, [allUsers, searchTerm, statusFilter, genderFilter, ageFilter, accountStatusFilter]);

  useEffect(() => {
    filterUsers();
  }, [filterUsers]);

  const loadUsers = async () => {
    setLoading(true);
    try {
      const users = await User.list('-created_date');
      setAllUsers(users);
    } catch (error) {
      console.error("Erro ao carregar usuários:", error);
    }
    setLoading(false);
  };

  const handlePunish = async (userId) => {
    if (window.confirm("Tem certeza que deseja banir este usuário? Ele perderá o acesso ao aplicativo.")) {
      try {
        await User.update(userId, { account_status: 'banned' });
        loadUsers();
      } catch (error) {
        console.error("Erro ao banir usuário:", error);
      }
    }
  };

  const handleUnban = async (userId) => {
     if (window.confirm("Tem certeza que deseja reativar este usuário? Ele recuperará o acesso ao aplicativo.")) {
      try {
        await User.update(userId, { account_status: 'active' });
        loadUsers();
      } catch (error) {
        console.error("Erro ao reativar usuário:", error);
      }
    }
  };

  const clearFilters = () => {
    setSearchTerm("");
    setStatusFilter("all");
    setGenderFilter("all");
    setAgeFilter("all");
    setAccountStatusFilter("all");
  };

  const getSubscriptionStatusStyle = (status) => {
    switch (status) {
      case 'active':
        return 'bg-green-500/20 text-green-300 border-green-500/30';
      case 'inactive':
        return 'bg-red-500/20 text-red-300 border-red-500/30';
      case 'pending':
        return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      default:
        return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  const getAccountStatusStyle = (status) => {
    status = status || 'active';
    switch (status) {
      case 'active':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/30';
      case 'banned':
        return 'bg-red-500/20 text-red-300 border-red-500/30';
      default:
        return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case 'active': return 'Ativo';
      case 'inactive': return 'Inativo';
      case 'pending': return 'Pendente';
      default: return 'N/A';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-yellow-400"></div>
      </div>
    );
  }

  const hasActiveFilters = searchTerm || statusFilter !== "all" || genderFilter !== "all" || ageFilter !== "all" || accountStatusFilter !== "all";

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-4xl font-black tracking-tighter text-white">Gerenciamento de Usuários</h1>
        <p className="text-neutral-400 text-lg mt-1">
          Visualize e gerencie todos os participantes da plataforma.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
        <Card className="bg-neutral-800/50 border border-white/10">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-white">{allUsers.length}</div>
            <div className="text-sm text-neutral-400">Total</div>
          </CardContent>
        </Card>
        <Card className="bg-green-500/10 border border-green-500/30">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-400">
              {allUsers.filter(u => u.subscription_status === 'active').length}
            </div>
            <div className="text-sm text-neutral-400">Assinantes</div>
          </CardContent>
        </Card>
        <Card className="bg-yellow-500/10 border border-yellow-500/30">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-yellow-400">
              {allUsers.filter(u => u.subscription_status === 'pending').length}
            </div>
            <div className="text-sm text-neutral-400">Pendentes</div>
          </CardContent>
        </Card>
        <Card className="bg-red-500/10 border border-red-500/30">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-400">
              {allUsers.filter(u => u.subscription_status === 'inactive').length}
            </div>
            <div className="text-sm text-neutral-400">Inativos</div>
          </CardContent>
        </Card>
         <Card className="bg-red-800/20 border border-red-500/30">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-400">
              {allUsers.filter(u => u.account_status === 'banned').length}
            </div>
            <div className="text-sm text-neutral-400">Banidos</div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-neutral-800/50 border border-white/10">
        <CardHeader>
          <CardTitle className="flex items-center justify-between text-white">
            <div className="flex items-center gap-3">
              <UsersIcon className="w-6 h-6 text-yellow-400" />
              <span>Usuários ({filteredUsers.length})</span>
            </div>
            {hasActiveFilters && (
              <Button
                variant="ghost"
                size="sm"
                onClick={clearFilters}
                className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
              >
                <X className="w-4 h-4 mr-2" />
                Limpar Filtros
              </Button>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Filtros e Busca */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-neutral-400" />
              <Input
                placeholder="Buscar por nome, email ou telefone..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-neutral-900 border-neutral-600 text-white placeholder-neutral-400"
              />
            </div>

            <Select value={accountStatusFilter} onValueChange={setAccountStatusFilter}>
              <SelectTrigger className="w-full md:w-48 bg-neutral-900 border-neutral-600 text-white">
                <SelectValue placeholder="Status da Conta" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Status</SelectItem>
                <SelectItem value="active">Ativo</SelectItem>
                <SelectItem value="banned">Banido</SelectItem>
              </SelectContent>
            </Select>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-48 bg-neutral-900 border-neutral-600 text-white">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Status</SelectItem>
                <SelectItem value="active">Ativo</SelectItem>
                <SelectItem value="pending">Pendente</SelectItem>
                <SelectItem value="inactive">Inativo</SelectItem>
              </SelectContent>
            </Select>

            <Select value={genderFilter} onValueChange={setGenderFilter}>
              <SelectTrigger className="w-full md:w-48 bg-neutral-900 border-neutral-600 text-white">
                <SelectValue placeholder="Gênero" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos os Gêneros</SelectItem>
                <SelectItem value="masculino">Masculino</SelectItem>
                <SelectItem value="feminino">Feminino</SelectItem>
              </SelectContent>
            </Select>

            <Select value={ageFilter} onValueChange={setAgeFilter}>
              <SelectTrigger className="w-full md:w-48 bg-neutral-900 border-neutral-600 text-white">
                <SelectValue placeholder="Categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas as Idades</SelectItem>
                <SelectItem value="infantil">Infantil (5-13)</SelectItem>
                <SelectItem value="juvenil">Juvenil (14-17)</SelectItem>
                <SelectItem value="adulto">Adulto (18-30)</SelectItem>
                <SelectItem value="veterano">Veterano (31-40)</SelectItem>
                <SelectItem value="master">Master (41-70)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Tabela */}
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-white/10 hover:bg-neutral-800">
                  <TableHead className="text-white font-semibold">Nome</TableHead>
                  <TableHead className="text-white font-semibold">Email</TableHead>
                  <TableHead className="text-white font-semibold">Telefone</TableHead>
                  <TableHead className="text-white font-semibold text-center">Assinatura</TableHead>
                  <TableHead className="text-white font-semibold text-center">Status Conta</TableHead>
                  <TableHead className="text-white font-semibold text-center">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user) => {
                  const accountStatus = user.account_status || 'active';
                  return (
                    <TableRow key={user.id} className="border-white/10 hover:bg-neutral-800/50 transition-colors">
                      <TableCell>
                        <div className="font-medium text-white">{user.full_name}</div>
                        <div className="text-neutral-400 text-xs">{user.age || 'N/A'} anos, {user.gender || 'N/A'}</div>
                      </TableCell>
                      <TableCell className="text-neutral-300">{user.email}</TableCell>
                      <TableCell className="text-neutral-300">{user.phone || 'N/A'}</TableCell>
                      <TableCell className="text-center">
                        <Badge className={`font-semibold ${getSubscriptionStatusStyle(user.subscription_status)}`}>
                          {getStatusLabel(user.subscription_status)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge className={`font-semibold ${getAccountStatusStyle(accountStatus)}`}>
                          {accountStatus === 'active' ? 'Ativo' : 'Banido'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        {accountStatus === 'active' ? (
                          <Button variant="destructive" size="sm" onClick={() => handlePunish(user.id)}>
                            <ShieldOff className="w-4 h-4 mr-2" /> Punir
                          </Button>
                        ) : (
                          <Button variant="secondary" size="sm" onClick={() => handleUnban(user.id)} className="bg-green-600 hover:bg-green-700 text-white">
                            <ShieldCheck className="w-4 h-4 mr-2" /> Reativar
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>

            {filteredUsers.length === 0 && (
              <div className="text-center py-8">
                <Filter className="w-12 h-12 text-neutral-500 mx-auto mb-4" />
                <p className="text-neutral-400 text-lg mb-2">Nenhum usuário encontrado</p>
                <p className="text-neutral-500">
                  {hasActiveFilters
                    ? "Tente ajustar os filtros de busca"
                    : "Nenhum usuário cadastrado ainda"
                  }
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
