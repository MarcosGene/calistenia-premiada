
import React, { useState, useEffect } from "react";
import { Challenge } from "@/api/entities";
import { VideoSubmission } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  Settings, 
  Plus, 
  Trophy, 
  Users,
  Video,
  DollarSign,
  ShieldOff,
  ShieldCheck,
  CheckCircle // Added CheckCircle import
} from "lucide-react";

export default function Admin() {
  const [currentChallenge, setCurrentChallenge] = useState(null);
  const [pendingVideos, setPendingVideos] = useState([]);
  const [stats, setStats] = useState({ users: 0, videos: 0, totalPrizes: 0 });
  const [loading, setLoading] = useState(true);
  const [newChallenge, setNewChallenge] = useState({
    exercise_type: 'flexao',
    prize_amount: 100,
    week_start: '',
    week_end: ''
  });

  useEffect(() => {
    loadAdminData();
  }, []);

  const loadAdminData = async () => {
    try {
      // Carregar desafio atual
      const challenges = await Challenge.filter({ is_active: true }, '-created_date', 1);
      if (challenges.length > 0) {
        setCurrentChallenge(challenges[0]);
      }

      // Carregar apenas vídeos rejeitados ou que precisam de revisão manual (novo foco do painel)
      const videos = await VideoSubmission.filter({ status: 'rejected' }, '-created_date');
      setPendingVideos(videos);

      // Carregar estatísticas
      const users = await User.list();
      const allVideos = await VideoSubmission.list();
      
      setStats({
        users: users.length,
        videos: allVideos.length,
        totalPrizes: users.reduce((sum, user) => sum + (user.total_prizes_won || 0), 0)
      });

    } catch (error) {
      console.error("Erro ao carregar dados admin:", error);
    }
    setLoading(false);
  };

  const createNewChallenge = async (e) => {
    e.preventDefault();
    try {
      // Desativar desafio atual
      if (currentChallenge) {
        await Challenge.update(currentChallenge.id, { is_active: false });
      }

      // Criar novo desafio
      await Challenge.create({
        ...newChallenge,
        is_active: true
      });

      // Recarregar dados
      loadAdminData();
      
      // Limpar formulário
      setNewChallenge({
        exercise_type: 'flexao',
        prize_amount: 100,
        week_start: '',
        week_end: ''
      });

    } catch (error) {
      console.error("Erro ao criar desafio:", error);
    }
  };

  const approveVideo = async (videoId, count) => {
    try {
      await VideoSubmission.update(videoId, {
        status: 'approved',
        manual_count: count
      });
      loadAdminData();
    } catch (error) {
      console.error("Erro ao aprovar vídeo:", error);
    }
  };

  const rejectVideo = async (videoId) => {
    try {
      await VideoSubmission.update(videoId, {
        status: 'rejected'
      });
      loadAdminData();
    } catch (error) {
      console.error("Erro ao rejeitar vídeo:", error);
    }
  };

  const banUser = async (userId, userName) => {
    if (window.confirm(`Tem certeza que deseja BANIR o usuário ${userName}? Ele perderá o acesso ao aplicativo.`)) {
      try {
        await User.update(userId, { account_status: 'banned' });
        loadAdminData();
        alert(`Usuário ${userName} foi banido com sucesso.`);
      } catch (error) {
        console.error("Erro ao banir usuário:", error);
      }
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 to-black flex items-center justify-center">
        <div className="flex items-center gap-3 text-white">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-500"></div>
          <span className="text-xl font-bold">Carregando admin...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-black p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-black text-white mb-2">
            ⚙️ Painel Administrativo
          </h1>
          <p className="text-gray-300">
            Gerencie desafios, vídeos e usuários
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-black/50 backdrop-blur-sm border-red-500/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-300 text-sm font-medium">Total Usuários</p>
                  <p className="text-3xl font-bold text-white">{stats.users}</p>
                </div>
                <Users className="w-8 h-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/50 backdrop-blur-sm border-red-500/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-300 text-sm font-medium">Vídeos Enviados</p>
                  <p className="text-3xl font-bold text-white">{stats.videos}</p>
                </div>
                <Video className="w-8 h-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/50 backdrop-blur-sm border-red-500/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-300 text-sm font-medium">Vídeos Pendentes</p>
                  <p className="text-3xl font-bold text-yellow-500">{pendingVideos.length}</p>
                </div>
                <Trophy className="w-8 h-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-black/50 backdrop-blur-sm border-red-500/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-300 text-sm font-medium">Prêmios Pagos</p>
                  <p className="text-3xl font-bold text-green-400">R$ {stats.totalPrizes}</p>
                </div>
                <DollarSign className="w-8 h-8 text-green-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="challenge" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 bg-black/50">
            <TabsTrigger value="challenge" className="data-[state=active]:bg-red-500">
              Desafios
            </TabsTrigger>
            <TabsTrigger value="videos" className="data-[state=active]:bg-red-500">
              Vídeos Pendentes ({pendingVideos.length})
            </TabsTrigger>
            <TabsTrigger value="winners" className="data-[state=active]:bg-red-500">
              Vencedores
            </TabsTrigger>
          </TabsList>

          <TabsContent value="challenge">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Desafio Atual */}
              <Card className="bg-black/50 backdrop-blur-sm border-red-500/30">
                <CardHeader>
                  <CardTitle className="text-white">Desafio Atual</CardTitle>
                </CardHeader>
                <CardContent>
                  {currentChallenge ? (
                    <div className="space-y-4">
                      <div>
                        <p className="text-gray-300">Exercício:</p>
                        <Badge className="bg-red-500 text-white capitalize">
                          {currentChallenge.exercise_type}
                        </Badge>
                      </div>
                      <div>
                        <p className="text-gray-300">Prêmio:</p>
                        <p className="text-2xl font-bold text-yellow-500">
                          R$ {currentChallenge.prize_amount}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-300">Período:</p>
                        <p className="text-white">
                          {currentChallenge.week_start} - {currentChallenge.week_end}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <p className="text-gray-400">Nenhum desafio ativo</p>
                  )}
                </CardContent>
              </Card>

              {/* Criar Novo Desafio */}
              <Card className="bg-black/50 backdrop-blur-sm border-red-500/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Plus className="w-5 h-5" />
                    Criar Novo Desafio
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={createNewChallenge} className="space-y-4">
                    <div>
                      <Label className="text-white">Exercício</Label>
                      <Select
                        value={newChallenge.exercise_type}
                        onValueChange={(value) => setNewChallenge({...newChallenge, exercise_type: value})}
                      >
                        <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="flexao">Flexão</SelectItem>
                          <SelectItem value="agachamento">Agachamento</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="text-white">Prêmio (R$)</Label>
                      <Input
                        type="number"
                        value={newChallenge.prize_amount}
                        onChange={(e) => setNewChallenge({...newChallenge, prize_amount: parseInt(e.target.value)})}
                        className="bg-gray-800 border-gray-600 text-white"
                      />
                    </div>

                    <div>
                      <Label className="text-white">Início</Label>
                      <Input
                        type="date"
                        value={newChallenge.week_start}
                        onChange={(e) => setNewChallenge({...newChallenge, week_start: e.target.value})}
                        className="bg-gray-800 border-gray-600 text-white"
                      />
                    </div>

                    <div>
                      <Label className="text-white">Fim</Label>
                      <Input
                        type="date"
                        value={newChallenge.week_end}
                        onChange={(e) => setNewChallenge({...newChallenge, week_end: e.target.value})}
                        className="bg-gray-800 border-gray-600 text-white"
                      />
                    </div>

                    <Button type="submit" className="w-full bg-yellow-500 hover:bg-yellow-400 text-black font-bold">
                      Criar Desafio
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="videos">
            <div className="space-y-4">
              <div className="bg-blue-500/10 p-4 rounded-lg border border-blue-500/30">
                <h3 className="text-blue-300 font-bold mb-2">ℹ️ Novo Sistema de Aprovação</h3>
                <p className="text-blue-200 text-sm">
                  Os vídeos agora são aprovados automaticamente após confirmação da IA. 
                  Para revisar e verificar os top 10 de cada categoria, acesse a página <strong>Ranking</strong> onde você pode ver os vídeos dos primeiros colocados. Este painel agora é apenas para vídeos que precisam de revisão manual (rejeitados).
                </p>
              </div>
              
              {pendingVideos.map((video) => (
                <VideoReviewCard 
                  key={video.id} 
                  video={video} 
                  onApprove={approveVideo}
                  onReject={rejectVideo}
                  onBanUser={banUser}
                />
              ))}
              {pendingVideos.length === 0 && (
                <Card className="bg-black/50 backdrop-blur-sm border-red-500/30">
                  <CardContent className="text-center py-8">
                    <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-4" />
                    <p className="text-green-400 font-semibold">Todos os vídeos rejeitados foram revisados!</p>
                    <p className="text-gray-400 mt-2">Acesse o Ranking para revisar os top 10 de cada categoria.</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="winners">
            <Card className="bg-black/50 backdrop-blur-sm border-red-500/30">
              <CardHeader>
                <CardTitle className="text-white">Selecionar Vencedores</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">
                  Funcionalidade em desenvolvimento - Os vencedores serão selecionados automaticamente baseado no ranking.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function VideoReviewCard({ video, onApprove, onReject, onBanUser }) {
  const [manualCount, setManualCount] = useState(video.ai_count || 0);

  return (
    <Card className="bg-black/50 backdrop-blur-sm border-red-500/30">
      <CardContent className="p-6">
        <div className="space-y-4">
          {/* Dados do Usuário */}
          <div className="bg-neutral-800/50 p-4 rounded-lg">
            <h4 className="text-yellow-400 font-bold text-lg mb-2">📱 Dados do Usuário</h4>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <p className="text-neutral-400 text-sm">Nome Completo:</p>
                <p className="text-white font-semibold">{video.user_full_name || 'N/A'}</p>
              </div>
              <div>
                <p className="text-neutral-400 text-sm">Telefone:</p>
                <p className="text-white font-semibold">Em desenvolvimento</p>
              </div>
              <div>
                <p className="text-neutral-400 text-sm">Idade:</p>
                <p className="text-white font-semibold">{video.user_age || 'N/A'} anos</p>
              </div>
              <div>
                <p className="text-neutral-400 text-sm">Gênero:</p>
                <p className="text-white font-semibold capitalize">{video.user_gender || 'N/A'}</p>
              </div>
            </div>
          </div>

          {/* Dados do Vídeo */}
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <h3 className="text-white font-bold mb-2">
                🎥 Vídeo ID: {video.id.substring(0, 8)}...
              </h3>
              <p className="text-gray-300 mb-2">
                Contagem IA: <span className="text-yellow-500 font-bold">{video.ai_count}</span>
              </p>
              <div className="flex items-center gap-2 mb-4">
                <Label className="text-white">Contagem Manual:</Label>
                <Input
                  type="number"
                  value={manualCount}
                  onChange={(e) => setManualCount(parseInt(e.target.value))}
                  className="w-24 bg-gray-800 border-gray-600 text-white"
                />
              </div>
            </div>
          </div>
          
          {/* Ações */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-white/10">
            <div className="flex gap-2 flex-1">
              <Button
                onClick={() => onApprove(video.id, manualCount)}
                className="bg-green-600 hover:bg-green-700 text-white flex-1"
              >
                ✅ Aprovar
              </Button>
              <Button
                onClick={() => onReject(video.id)}
                variant="destructive"
                className="flex-1"
              >
                ❌ Rejeitar
              </Button>
            </div>
            
            <Button
              onClick={() => onBanUser(video.user_id, video.user_full_name)}
              className="bg-red-800 hover:bg-red-900 text-white font-bold"
            >
              <ShieldOff className="w-4 h-4 mr-2" />
              🚫 BANIR USUÁRIO
            </Button>
          </div>
          
          <div className="pt-2">
            <a 
              href={video.video_url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-400 hover:text-blue-300 underline font-medium"
            >
              🔗 Ver Vídeo Completo
            </a>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
