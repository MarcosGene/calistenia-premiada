import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function TermsOfService() {
  const currentDate = new Date().toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  });

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      <Card className="bg-neutral-800/50 border border-white/10 text-white">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-yellow-400">Termos de Uso e Serviço</CardTitle>
          <p className="text-neutral-400">Última atualização: {currentDate}</p>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[60vh] pr-4">
            <div className="space-y-6 text-neutral-300">
              <section>
                <h2 className="text-xl font-semibold text-white mb-2">1. Aceitação dos Termos</h2>
                <p>
                  Ao se registrar e utilizar o aplicativo Calistenia Premiada ("Serviço"), você concorda em cumprir e estar sujeito a estes Termos de Uso e Serviço ("Termos"). Se você não concorda com estes Termos, não deve acessar ou usar o Serviço.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-white mb-2">2. Descrição do Serviço</h2>
                <p>
                  O Calistenia Premiada é uma plataforma de competição online que permite aos usuários ("Usuários") participar de desafios semanais de calistenia, enviar vídeos de seu desempenho para contagem e validação por Inteligência Artificial (IA) e administradores, e competir por prêmios em dinheiro.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-white mb-2">3. Elegibilidade e Contas de Usuário</h2>
                <p>
                  Para usar o Serviço, você deve ter pelo menos 5 anos de idade. Ao criar uma conta, você concorda em fornecer informações precisas e completas. Você é responsável por manter a confidencialidade de sua conta e por todas as atividades que ocorrem sob ela.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-white mb-2">4. Submissão de Conteúdo e Uso de Imagem</h2>
                <p>
                  Ao enviar um vídeo ("Conteúdo") para um desafio no Serviço, você declara e garante que:
                </p>
                <ul className="list-disc list-inside space-y-2 pl-4 mt-2">
                  <li>Você possui todos os direitos sobre o Conteúdo ou tem autoridade para conceder os direitos aqui mencionados.</li>
                  <li>O Conteúdo não viola os direitos de privacidade, direitos autorais, ou quaisquer outros direitos de terceiros.</li>
                </ul>
                <div className="mt-4 font-semibold text-yellow-300 bg-yellow-500/10 p-4 rounded-lg border border-yellow-500/20">
                  <h3 className="text-lg text-yellow-300 mb-2">Licença de Uso de Imagem e Vídeo</h3>
                  <p className="font-normal text-yellow-200">
                    Você concede ao Calistenia Premiada uma licença mundial, não exclusiva, isenta de royalties e transferível para usar, reproduzir, exibir e analisar o seu vídeo (incluindo sua imagem, voz e semelhança) para os seguintes fins:
                  </p>
                   <ul className="list-disc list-inside space-y-2 pl-4 mt-3 font-normal text-yellow-200">
                    <li>Processamento e contagem de repetições por meio de nosso sistema de Inteligência Artificial.</li>
                    <li>Verificação e validação manual por administradores autorizados, especialmente para os vídeos dos 10 primeiros colocados no ranking.</li>
                    <li>Exibição do seu vídeo dentro da plataforma, visível apenas para administradores, para fins de ranking e verificação.</li>
                    <li>Resolução de disputas e investigação de possíveis violações das regras.</li>
                  </ul>
                  <p className="mt-3 font-normal text-yellow-200">
                    Entendemos a sensibilidade deste conteúdo e nos comprometemos a usar sua imagem apenas dentro do escopo necessário para a operação justa e transparente da competição.
                  </p>
                </div>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-white mb-2">5. Conduta do Usuário</h2>
                <p>
                  Você concorda em não usar o Serviço para qualquer finalidade ilegal ou proibida. Atividades como fraude, tentativa de manipular o sistema de contagem, assédio a outros usuários ou envio de conteúdo impróprio resultarão na terminação imediata da sua conta e banimento permanente do Serviço.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-white mb-2">6. Assinaturas e Pagamentos</h2>
                <p>
                  A participação nos desafios requer uma assinatura ativa. As taxas de assinatura são recorrentes e serão cobradas mensalmente. Você pode cancelar sua assinatura a qualquer momento através da página "Assinatura".
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-white mb-2">7. Prêmios</h2>
                <p>
                  Os prêmios são concedidos aos vencedores de cada categoria, conforme determinado pelo ranking final de cada desafio. O pagamento será coordenado com os vencedores através das informações de contato fornecidas.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-white mb-2">8. Rescisão</h2>
                <p>
                  Nós nos reservamos o direito de suspender ou encerrar sua conta a qualquer momento, sem aviso prévio, por qualquer violação destes Termos.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-white mb-2">9. Alterações nos Termos</h2>
                <p>
                  Podemos modificar estes Termos a qualquer momento. Notificaremos sobre alterações significativas. O uso continuado do Serviço após tais alterações constitui sua aceitação dos novos Termos.
                </p>
              </section>

              <section>
                <h2 className="text-xl font-semibold text-white mb-2">10. Contato</h2>
                <p>
                  Se você tiver alguma dúvida sobre estes Termos, entre em contato conosco através do email: [email de contato].
                </p>
              </section>
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
      <div className="text-center mt-6">
        <Link to={createPageUrl("Dashboard")} className="text-yellow-400 hover:underline">
          &larr; Voltar para o Dashboard
        </Link>
      </div>
    </div>
  );
}