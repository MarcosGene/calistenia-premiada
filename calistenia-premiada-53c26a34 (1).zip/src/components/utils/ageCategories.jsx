export function getAgeCategory(age) {
  if (age >= 5 && age <= 13) return { key: 'infantil', label: 'Infantil (5-13)' };
  if (age >= 14 && age <= 17) return { key: 'juvenil', label: 'Juvenil (14-17)' };
  if (age >= 18 && age <= 30) return { key: 'adulto', label: 'Adulto (18-30)' };
  if (age >= 31 && age <= 40) return { key: 'veterano', label: 'Veterano (31-40)' };
  if (age >= 41 && age <= 70) return { key: 'master', label: 'Master (41-70)' };
  return { key: 'outros', label: 'Outros' };
}

export const AGE_CATEGORIES = [
  { key: 'infantil', label: 'Infantil (5-13)', emoji: '🧒' },
  { key: 'juvenil', label: 'Juvenil (14-17)', emoji: '👦' },
  { key: 'adulto', label: 'Adulto (18-30)', emoji: '👨' },
  { key: 'veterano', label: 'Veterano (31-40)', emoji: '🧔' },
  { key: 'master', label: 'Master (41-70)', emoji: '👴' }
];